# code/scripts/mp4wall.py
"""
mp4wall.py
Phase1 + Phase2 features:
- tapeciarnia: URI handling (Windows protocol style)
- Single input field URL validation (mp4/jpg/png) + local paths
- Reset settings: stop players and restore previous wallpaper
- Language JSON loader
- Tray + Drop-to-tray on close
- Drag & Drop files onto window to set wallpaper
- Smooth cross-fade for image wallpapers
- Auto-rotation scheduler (local folder or playlist URL)
- Autopause start/stop
"""

import os
import sys
import json
import shutil
import subprocess
import locale
import re
import time
import random
from pathlib import Path
from typing import Optional, List

from PySide6.QtWidgets import (
    QApplication, QMainWindow, QFileDialog, QMessageBox, QSystemTrayIcon, QMenu, QWidget,
    QDialog, QVBoxLayout, QLabel, QProgressBar
)
from PySide6.QtGui import QAction

from PySide6.QtGui import QIcon, QPixmap, QDragEnterEvent, QDropEvent, QPainter, QColor, QBrush
from PySide6.QtCore import QThread, Signal, Qt, QTimer, QPropertyAnimation, QEasingCurve, Property

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "")))
from ui.mainUI import Ui_MainWindow

# -------------------------
# Paths & config
# -------------------------
BASE_DIR = Path(__file__).resolve().parent
ROOT_DIR = BASE_DIR.parent.parent
CONFIG_PATH = ROOT_DIR / "config.json"
DOWNLOAD_PATH = ROOT_DIR / "Downloads"
TMP_DOWNLOAD_FILE = DOWNLOAD_PATH / "download_path.tmp"
TRANSLATIONS_DIR = BASE_DIR / "translations"  # <-- JSON translations live here
DOWNLOADS_DIR = Path.home() / "Videos" / "TapeciarniaDownloads"
DOWNLOADS_DIR.mkdir(parents=True, exist_ok=True)

DOWNLOAD_PATH.mkdir(parents=True, exist_ok=True)
if not CONFIG_PATH.exists():
    CONFIG_PATH.write_text(json.dumps({}), encoding="utf-8")


# -------------------------
# Helpers
# -------------------------
def which(cmd: str) -> Optional[str]:
    return shutil.which(cmd)


def is_image_url_or_path(s: str) -> bool:
    s = s.lower()
    return bool(re.search(r"\.(jpe?g|png)$", s)) or s.startswith("http") and bool(re.search(r"\.(jpe?g|png)(\?.*)?$", s))


def is_video_url_or_path(s: str) -> bool:
    s = s.lower()
    return bool(re.search(r"\.(mp4|mkv|webm|avi)$", s)) or s.startswith("http") and bool(re.search(r"\.(mp4|mkv|webm|avi)(\?.*)?$", s))


def validate_url_or_path(s: str) -> Optional[str]:
    s = s.strip()
    if not s:
        return None
    # Local file?
    if Path(s).exists():
        return s
    # Simple http(s) URL
    if s.lower().startswith("http://") or s.lower().startswith("https://"):
        return s
    # tapeciarnia scheme
    if s.lower().startswith("tapeciarnia:"):
        # Format: tapeciarnia:[https://example.com/f.mp4]
        # Extract inside brackets or after colon
        m = re.match(r"tapeciarnia:\[?(.*)\]?$", s, re.IGNORECASE)
        if m:
            url = m.group(1).strip()
            return url
    return None


def current_system_locale() -> str:
    try:
        lang, _ = locale.getdefaultlocale()
        if lang:
            return lang.split("_")[0]
    except Exception:
        pass
    return "en"


# -------------------------
# Wallpaper helpers (get/set current static wallpaper)
# -------------------------
def get_current_desktop_wallpaper() -> Optional[str]:
    """Return current static wallpaper with platform-specific methods; None if unavailable."""
    if sys.platform.startswith("win"):
        try:
            import ctypes, ctypes.wintypes
            SPI_GETDESKWALLPAPER = 0x0073
            buf = ctypes.create_unicode_buffer(260)
            ctypes.windll.user32.SystemParametersInfoW(SPI_GETDESKWALLPAPER, 260, buf, 0)
            return buf.value or None
        except Exception:
            return None
    elif sys.platform.startswith("linux"):
        # Try gsettings (GNOME)
        try:
            res = subprocess.run(["gsettings", "get", "org.gnome.desktop.background", "picture-uri"],
                                  capture_output=True, text=True)
            if res.returncode == 0:
                val = res.stdout.strip().strip("'\"")
                # gsettings returns 'file:///path'
                if val.startswith("file://"):
                    return val[7:]
                return val
        except Exception:
            pass
        # fallback None
        return None
    elif sys.platform == "darwin":
        # macOS retrieval complex; return None for now
        return None
    return None


def set_static_desktop_wallpaper(path: str):
    """Set a static wallpaper (image) using system tools when resetting."""
    if sys.platform.startswith("win"):
        try:
            import ctypes
            SPI_SETDESKWALLPAPER = 20
            ctypes.windll.user32.SystemParametersInfoW(SPI_SETDESKWALLPAPER, 0, str(path), 3)
            return True
        except Exception:
            return False
    elif sys.platform.startswith("linux"):
        # Try gsettings for GNOME
        try:
            # Ensure path is absolute and has file://
            uri = f"file://{str(path)}"
            subprocess.run(["gsettings", "set", "org.gnome.desktop.background", "picture-uri", uri])
            return True
        except Exception:
            return False
    return False


# -------------------------
# Wallpaper controller (same as previous but simplified)
# -------------------------
class WallpaperController:
    def __init__(self):
        self.player_proc = []
        self.current_is_video = False

    def stop(self):
        # Kill processes we spawn or known names
        # (keeps consistent with autopause / weebp usage)
        if sys.platform.startswith("linux"):
            subprocess.call("pkill -f xwinwrap", shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            subprocess.call("pkill -f mpv", shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        elif sys.platform.startswith("win"):
            subprocess.call("taskkill /F /IM mpv.exe", shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            subprocess.call("taskkill /F /IM ffplay.exe", shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        for p in self.player_proc:
            try:
                p.terminate()
            except Exception:
                pass
        self.player_proc = []
        self.current_is_video = False

    def start_video(self, video_path: str):
        self.stop()
        self.current_is_video = True
        if sys.platform.startswith("linux"):
            # prefer xwinwrap + mpv if available
            xw = which("xwinwrap")
            mpv = which("mpv")
            if xw and mpv:
                cmd = f"{xw} -ov -fs -- {mpv} --loop --no-audio --no-osd-bar --wid=WID '{video_path}'"
                p = subprocess.Popen(cmd, shell=True, executable="/bin/bash", stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                self.player_proc.append(p)
                return
            if mpv:
                p = subprocess.Popen([mpv, "--loop", "--no-audio", "--no-osd-bar", "--fullscreen", "--no-border", video_path],
                                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                self.player_proc.append(p)
                return
            raise RuntimeError("mpv not found")
        else:
            # windows: attempt mpv then ffplay
            mpv = which("mpv")
            if mpv:
                p = subprocess.Popen([mpv, "--loop", "--no-audio", "--fullscreen", "--no-border", video_path],
                                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                self.player_proc.append(p)
                return
            ffplay = which("ffplay")
            if ffplay:
                cmd = f'start "" /min "{ffplay}" -autoexit -loop 0 -an -fs "{video_path}"'
                subprocess.Popen(cmd, shell=True)
                return
            raise RuntimeError("No player found")

    def start_image(self, image_path: str, fade_widget=None):
        """
        For images we'll perform a cross-fade using Qt overlay (fade_widget is the UI overlay)
        But also set the system wallpaper as fallback (for real desktop).
        """
        self.stop()
        self.current_is_video = False
        try:
            set_static_desktop_wallpaper(image_path)
        except Exception:
            pass
        # If fade_widget is provided, widget handles visual transition (in UI)
        return


# -------------------------
# Autopause controller (same idea)
# -------------------------
class AutoPauseController:
    def __init__(self):
        self.proc = None

    def autopause_path(self) -> Optional[Path]:
        candidates = [
            BASE_DIR / "bin" / "tools" / "autopause.exe",
            BASE_DIR / "bin" / "tools" / "autopause"
        ]
        for c in candidates:
            if c.exists():
                return c
        return None

    def start(self):
        path = self.autopause_path()
        if path:
            try:
                self.proc = subprocess.Popen([str(path)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                return True
            except Exception:
                self.proc = None
        return False

    def stop(self):
        if self.proc:
            try:
                self.proc.terminate()
            except Exception:
                pass
            self.proc = None


# -------------------------
# Downloader (same behavior as before)
# -------------------------
class DownloaderThread(QThread):
    progress = Signal(float)
    done = Signal(str)
    error = Signal(str)

    def __init__(self, url: str, parent=None):
        super().__init__(parent)
        self.url = url

    def run(self):
        import yt_dlp
        from pathlib import Path

        try:
            def hook(d):
                """Update progress bar while downloading."""
                if d["status"] == "downloading":
                    total = d.get("total_bytes") or d.get("total_bytes_estimate", 1)
                    if total:
                        percent = d.get("downloaded_bytes", 0) / total * 100
                        self.progress.emit(percent)
                elif d["status"] == "finished":
                    self.progress.emit(100)

            # Simplify and let yt_dlp decide correct extension
            output_template = str(DOWNLOADS_DIR / "%(title)s.%(ext)s")

            ydl_opts = {
                "outtmpl": output_template,
                "format": "bestvideo+bestaudio/best",
                "merge_output_format": "mp4",
                "noplaylist": False,
                "quiet": True,
                "progress_hooks": [hook],
            }

            print(f"[yt_dlp] Downloading: {self.url}")
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(self.url, download=True)
                filename = ydl.prepare_filename(info)

                # Check for file existence and handle alternative extensions
                possible_files = [
                    Path(filename),
                    Path(filename).with_suffix(".mp4"),
                    Path(filename).with_suffix(".mkv"),
                    Path(filename).with_suffix(".webm"),
                ]

                existing_file = next((f for f in possible_files if f.exists()), None)
                if not existing_file:
                    raise FileNotFoundError(
                        f"yt_dlp finished but no usable file found for {filename}"
                    )

                print(f"[yt_dlp] Downloaded file: {existing_file}")
                self.done.emit(str(existing_file))

        except Exception as e:
            self.error.emit(str(e))
            self.done.emit("")


# -------------------------
# UI FadeOverlay (for smooth cross-fade of images)
# -------------------------
class FadeOverlay(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.setAttribute(Qt.WidgetAttribute.WA_NoSystemBackground)
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint)
        self._pixmap_old = None
        self._pixmap_new = None
        self._opacity = 0.0
        self.resize(parent.size() if parent else (800, 600))

    def set_pixmaps(self, old: Optional[QPixmap], new: Optional[QPixmap]):
        self._pixmap_old = old
        self._pixmap_new = new
        self._opacity = 0.0
        self.update()

    def paintEvent(self, e):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        if self._pixmap_old:
            painter.setOpacity(1.0)
            painter.drawPixmap(self.rect(), self._pixmap_old)
        if self._pixmap_new:
            painter.setOpacity(self._opacity)
            painter.drawPixmap(self.rect(), self._pixmap_new)

    def animate_to(self, duration=600):
        anim = QPropertyAnimation(self, b"overlayOpacity", self)
        anim.setStartValue(0.0)
        anim.setEndValue(1.0)
        anim.setDuration(duration)
        anim.setEasingCurve(QEasingCurve.Type.InOutQuad)
        anim.start()
        # keep reference
        self._anim = anim

    def getOpacity(self):
        return self._opacity

    def setOpacity(self, v):
        self._opacity = v
        self.update()

    overlayOpacity = Property(float, getOpacity, setOpacity)


# -------------------------
# Main Window (drag/drop + uri handling + scheduler)
# -------------------------

class DownloadProgressDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Downloading Video")
        self.setModal(True)
        self.setFixedSize(300, 100)

        layout = QVBoxLayout(self)
        self.label = QLabel("Preparing download...", self)
        self.progress = QProgressBar(self)
        self.progress.setRange(0, 100)
        layout.addWidget(self.label)
        layout.addWidget(self.progress)

    def update_progress(self, percent: float):
        self.progress.setValue(int(percent))
        self.label.setText(f"Downloading... {int(percent)}%")


class MP4WallApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)

        # controllers
        self.controller = WallpaperController()
        self.autopause = AutoPauseController()

        # overlay for transitions
        self.fade_overlay = FadeOverlay(self)
        self.fade_overlay.hide()

        # scheduler
        self.scheduler_timer = QTimer(self)
        self.scheduler_timer.timeout.connect(self._scheduler_tick)
        self.scheduler_source = None  # path or playlist url
        self.scheduler_interval_minutes = 30

        # track previous static wallpaper so reset can restore it
        self.previous_wallpaper = get_current_desktop_wallpaper()

        # UI binding
        self._autobind_ui()

        # enable drag/drop on main window
        self.setAcceptDrops(True)

        # tray
        self._setup_tray()

        # load language
        self._load_translations()

        # load config last video
        self._load_last_video()

        # parse CLI args (tapeciarnia: handler)
        self._handle_cli_args()

    # -------------------------
    # UI autobind (same fallback mapping)
    # -------------------------
    def _autobind_ui(self):
        attrs = self.ui.__dict__
        self.url_input = attrs.get("urlInput") or attrs.get("lineEdit_url") or attrs.get("urlInputField") or None
        self.status_label = attrs.get("statusLabel") or attrs.get("label_status") or None

        # Buttons - try many names
        for name in ("applyButton", "loadUrlButton", "pushButton_apply", "pushButton"):
            if name in attrs:
                self.apply_btn = attrs[name]
                self.apply_btn.clicked.connect(self.on_apply_clicked)
                break
        self.reset_btn = attrs.get("resetButton")
        if self.reset_btn:
            self.reset_btn.clicked.connect(self.on_reset_clicked)
        # There's already browseButton in your UI
        self.browse_btn = attrs.get("browseButton")
        if self.browse_btn:
            self.browse_btn.clicked.connect(self.on_browse_clicked)
        # Interval spinbox exists; connect to scheduler start/stop if present
        self.interval_spinbox = attrs.get("interval_spinBox")
        if self.interval_spinbox:
            # update interval variable
            self.interval_spinbox.valueChanged.connect(self._on_interval_changed)
        # source selection: allow selecting a folder via a plus button if available
        self.add_source_btn = attrs.get("added_wallpaper_btn") or attrs.get("super_wallpaper_btn")

        # loadUrlButton may exist (explicit)
        if hasattr(self.ui, "loadUrlButton"):
            self.ui.loadUrlButton.clicked.connect(self.on_apply_clicked)

    def _set_status(self, s: str):
        if self.status_label:
            try:
                self.status_label.setText(s)
            except Exception:
                print("[status]", s)
        else:
            print("[status]", s)

    # -------------------------
    # Drag & Drop overrides
    # -------------------------
    def dragEnterEvent(self, e: QDragEnterEvent):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()
        else:
            e.ignore()

    def dropEvent(self, e: QDropEvent):
        urls = e.mimeData().urls()
        if not urls:
            return
        # pick first file
        p = urls[0].toLocalFile()
        if not p:
            return
        p = str(Path(p))
        # apply immediately
        self._set_status(f"Dropped: {Path(p).name}")
        self._apply_input_string(p)

    # -------------------------
    # CLI / URI handling
    # -------------------------
    def _handle_cli_args(self):
        # If app launched with a tapeciarnia: URI (on Windows) or a URL argument, handle it
        if len(sys.argv) > 1:
            # Accept multiple forms: direct URL, tapeciarnia:[...], or file path
            arg = sys.argv[1]
            # sometimes GUI frameworks pass things differently; strip
            parsed = validate_cli_arg(arg)
            if parsed:
                self._set_status("Applying from URI...")
                self._apply_input_string(parsed)

    # -------------------------
    # Apply logic (common used by apply button / drag drop / cli)
    # -------------------------
    def on_browse_clicked(self):
        path, _ = QFileDialog.getOpenFileName(self, "Select video or image", str(Path.home()),
                                              "Media (*.mp4 *.mkv *.webm *.avi *.jpg *.jpeg *.png)")
        if path:
            if self.url_input:
                self.url_input.setText(path)
            self._apply_input_string(path)

    def on_apply_clicked(self):
        if not self.url_input:
            QMessageBox.warning(self, "Error", "No input field")
            return
        s = self.url_input.text().strip()
        if not s:
            QMessageBox.warning(self, "Error", "No URL/path provided")
            return
        self._apply_input_string(s)

    def _apply_input_string(self, text: str):
        """Handles both URLs and local paths for images and videos."""
        text = text.strip()
        if not text:
            QMessageBox.warning(self, "Warning", "Please enter a valid URL or file path.")
            return

        # Handle local paths
        p = Path(text)
        if p.exists():
            # Local file
            if p.suffix.lower() in [".mp4", ".mkv", ".avi", ".mov", ".webm"]:
                try:
                    self.autopause.start()
                    self.controller.start_video(str(p))
                    self._save_last_video(str(p))
                    self._set_status(f"Playing local video: {p.name}")
                except Exception as e:
                    QMessageBox.critical(self, "Error", f"Failed to play video: {e}")
            elif p.suffix.lower() in [".jpg", ".jpeg", ".png", ".bmp", ".gif"]:
                self.controller.set_wallpaper(str(p))
                self._save_last_image(str(p))
                self._set_status(f"Applied local image: {p.name}")
            else:
                QMessageBox.warning(self, "Unsupported File", "Please select a valid image or video file.")
            return

        # Handle URLs
        if text.lower().startswith("http"):
            # Direct image link
            if any(text.lower().endswith(ext) for ext in [".jpg", ".jpeg", ".png", ".bmp", ".gif"]):
                self._set_status("Applying image from URL...")
                self.controller.set_wallpaper(text)
                self._save_last_image(text)
                self._set_status("Image wallpaper applied successfully.")
                return

            # Assume it's a video (YouTube or direct link)
            self._set_status("Fetching video stream...")
            try:
                # Start async download using yt_dlp
                if TMP_DOWNLOAD_FILE.exists():
                    TMP_DOWNLOAD_FILE.unlink()

                # Show progress dialog
                self.progress_dialog = DownloadProgressDialog(self)
                self.downloader = DownloaderThread(text)
                self.downloader.progress.connect(self.progress_dialog.update_progress)
                self.downloader.done.connect(self._on_download_done)
                self.downloader.error.connect(lambda msg: QMessageBox.critical(self, "Download Error", msg))
                self.downloader.done.connect(self.progress_dialog.accept)
                self.downloader.start()
                self.progress_dialog.exec()
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to download video: {e}")
            return

        QMessageBox.warning(self, "Invalid Input", "Unsupported input type. Please provide a valid file path or URL.")


    def _on_download_done(self, path: str):
        if not path:
            self._set_status("Download failed.")
            return

        p = Path(path)
        if not p.exists():
            self._set_status("Downloaded file not found.")
            return

        # Handle supported video types
        if p.suffix.lower() in (".mp4", ".mkv", ".webm"):
            try:
                self.autopause.start()
                self.controller.start_video(str(p))
                self._save_last_video(str(p))
                self._set_status(f"Playing video: {p.name}")
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to play video: {e}")
        elif p.suffix.lower() in (".jpg", ".jpeg", ".png", ".bmp"):
            try:
                self.controller.set_wallpaper(str(p))
                self._save_last_image(str(p))
                self._set_status(f"Wallpaper set: {p.name}")
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to set wallpaper: {e}")
        else:
            QMessageBox.warning(self, "Unsupported file", f"Unsupported file type: {p.suffix}")

    # -------------------------
    # Image Fade transition
    # -------------------------
    def _apply_image_with_fade(self, image_path: str):
        try:
            old_pix = None
            # Try to capture current UI snapshot as QPixmap (not guaranteed)
            try:
                old_pix = self.grab()
            except Exception:
                old_pix = None
            new_pix = QPixmap(image_path)
            # scale to window
            new_pix = new_pix.scaled(self.size(), Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
            self.fade_overlay.set_pixmaps(old_pix, new_pix)
            self.fade_overlay.show()
            self.fade_overlay.raise_()
            self.fade_overlay.animate_to(duration=650)
            # also set system wallpaper
            set_static_desktop_wallpaper(image_path)
            QTimer.singleShot(700, self.fade_overlay.hide)
            self._set_status(f"Image applied: {Path(image_path).name}")
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Fade apply failed: {e}")

    # -------------------------
    # Reset settings (stop wallpaper + restore previous)
    # -------------------------
    def on_reset_clicked(self):
        self._perform_reset()

    def _perform_reset(self):
        # Stop wallpaper players + autopause
        try:
            self.controller.stop()
        except Exception:
            pass
        try:
            self.autopause.stop()
        except Exception:
            pass
        # restore saved previous static wallpaper
        if self.previous_wallpaper:
            ok = set_static_desktop_wallpaper(self.previous_wallpaper)
            if ok:
                self._set_status("Restored previous wallpaper")
                return
        # fallback: clear to default (platform-specific)
        self._set_status("Reset complete (previous wallpaper unavailable)")

    # -------------------------
    # Scheduler for automatic changing
    # -------------------------
    def start_scheduler(self, source: str, interval_minutes: int = 30):
        """
        source: either a local folder (path) or a playlist URL (that downloader can parse)
        """
        self.scheduler_source = source
        self.scheduler_interval_minutes = max(1, int(interval_minutes))
        self.scheduler_timer.start(self.scheduler_interval_minutes * 60 * 1000)
        self._set_status(f"Scheduler started: every {self.scheduler_interval_minutes} min")

    def stop_scheduler(self):
        self.scheduler_timer.stop()
        self.scheduler_source = None
        self._set_status("Scheduler stopped")

    def _scheduler_tick(self):
        if not self.scheduler_source:
            return
        src = self.scheduler_source
        if Path(src).exists() and Path(src).is_dir():
            vids = [p for p in Path(src).iterdir() if p.suffix.lower() in (".mp4", ".mkv", ".webm", ".avi", ".jpg", ".png")]
            if not vids:
                self._set_status("Scheduler: no media in source")
                return
            chosen = str(random.choice(vids))
            self._apply_input_string(chosen)
            return
        else:
            # treat as URL playlist -> download then apply first available
            self.downloader = DownloaderThread(src)
            self.downloader.done.connect(self._on_download_done)
            self.downloader.start()

    def _on_interval_changed(self, val):
        self.scheduler_interval_minutes = val
        if self.scheduler_timer.isActive():
            self.scheduler_timer.start(self.scheduler_interval_minutes * 60 * 1000)
            self._set_status(f"Scheduler interval set to {val} min")

    # -------------------------
    # Persist last path
    # -------------------------
    def _save_last_video(self, path: str):
        try:
            cfg = {}
            if CONFIG_PATH.exists():
                try:
                    cfg = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
                except Exception:
                    cfg = {}
            cfg["last_video"] = path
            cfg["scheduler_source"] = self.scheduler_source
            cfg["scheduler_interval"] = self.scheduler_interval_minutes
            CONFIG_PATH.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
        except Exception as e:
            print("[CONFIG] failed to save:", e)

    def _load_last_video(self):
        try:
            if CONFIG_PATH.exists():
                cfg = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
                last = cfg.get("last_video")
                sc = cfg.get("scheduler_source")
                si = cfg.get("scheduler_interval")
                if last and self.url_input:
                    try:
                        self.url_input.setText(last)
                    except Exception:
                        pass
                if sc:
                    self.scheduler_source = sc
                if si:
                    self.scheduler_interval_minutes = si
                    if self.interval_spinbox:
                        try:
                            self.interval_spinbox.setValue(int(si))
                        except Exception:
                            pass
        except Exception:
            pass

    # -------------------------
    # Tray behavior
    # -------------------------
    def _setup_tray(self):
        QApplication.setQuitOnLastWindowClosed(False)
        icon = QIcon()
        # try to load project icon first
        cand = BASE_DIR / "ui" / "icons" / "logo_biale.svg"
        if cand.exists():
            icon = QIcon(str(cand))
        self.tray = QSystemTrayIcon(icon, parent=self)
        menu = QMenu()
        show_action = QAction("Show", self)
        show_action.triggered.connect(self.show)
        hide_action = QAction("Hide", self)
        hide_action.triggered.connect(self.hide)
        exit_action = QAction("Exit", self)
        exit_action.triggered.connect(self._exit_app)
        menu.addAction(show_action)
        menu.addAction(hide_action)
        menu.addSeparator()
        menu.addAction(exit_action)
        self.tray.setContextMenu(menu)
        self.tray.activated.connect(self._tray_activated)
        self.tray.show()

    def _tray_activated(self, reason):
        if reason == QSystemTrayIcon.DoubleClick:
            self.show()

    def _exit_app(self):
        try:
            self.controller.stop()
        except Exception:
            pass
        try:
            self.autopause.stop()
        except Exception:
            pass
        QApplication.quit()

    # -------------------------
    # Language / Translations
    # -------------------------
    def _load_translations(self):
        # If user has translations in translations/<lang>.json, load them.
        try:
            # Config language or system language
            cfg = {}
            if CONFIG_PATH.exists():
                try:
                    cfg = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
                except Exception:
                    cfg = {}
            preferred = cfg.get("language") or current_system_locale()
            # find matching translation file
            f = TRANSLATIONS_DIR / f"{preferred}.json"
            if not f.exists():
                # fallback to 'en.json'
                f = TRANSLATIONS_DIR / "en.json"
            if f.exists():
                data = json.loads(f.read_text(encoding="utf-8"))
                self._apply_translation(data)
        except Exception:
            pass

    def _apply_translation(self, mapping: dict):
        # mapping keys -> widget object names (simple)
        for widget_name, text in mapping.items():
            if hasattr(self.ui, widget_name):
                w = getattr(self.ui, widget_name)
                try:
                    if hasattr(w, "setText"):
                        w.setText(text)
                except Exception:
                    pass

# -------------------------
# CLI helper
# -------------------------
def validate_cli_arg(arg: str) -> Optional[str]:
    # Accept raw http(s), file paths or tapeciarnia:[...]
    parsed = validate_url_or_path(arg)
    if parsed:
        return parsed
    # Maybe user passed tapeciarnia:URL with bracket or without
    if arg.lower().startswith("tapeciarnia:"):
        m = re.match(r"tapeciarnia:\[?(.*)\]?$", arg, re.IGNORECASE)
        if m:
            return m.group(1).strip()
    return None


# -------------------------
# Entry
# -------------------------
def main():
    app = QApplication(sys.argv)
    window = MP4WallApp()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
